// 12-house allocation and astrological mapping

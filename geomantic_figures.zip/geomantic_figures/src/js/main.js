// Geomantic figure renderer and chart layout

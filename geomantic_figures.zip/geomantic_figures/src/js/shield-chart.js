// Mother/daughter/nephew/court generation

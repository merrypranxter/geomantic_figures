# Math Reference: geomantic_figures

> TODO: add mathematical foundations, equations, and reference values.

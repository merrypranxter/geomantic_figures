// TODO: house.frag

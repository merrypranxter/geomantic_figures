// 16 figure definitions and bit encoding

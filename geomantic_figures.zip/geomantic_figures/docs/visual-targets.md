# Visual Targets: geomantic_figures

> TODO: describe desired visual output, color palettes, and animation behavior.

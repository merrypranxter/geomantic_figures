// TODO: shield.frag
